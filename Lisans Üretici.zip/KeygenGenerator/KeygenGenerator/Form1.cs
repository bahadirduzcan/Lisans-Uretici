﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace KeygenGenerator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string pcId = ComputerInfo.GetComputerId();
        int kalanGun;

        private void Form1_Load(object sender, EventArgs e)
        {
            kalanGun = database.aktifKeyGunKontrol(pcId);

            //switch (kalanGun)
            //{
            //    case 0: Kapali(); break;
            //    case -1: Acik(); break;
            //    case -2: Kapali(); break;
            //    default: Acik(); break;
            //}

            //MessageBox.Show(DateTime.Now.ToString("hh:mm"));
        }

        void Kapali()
        {
            foreach (Control item in Controls)
            {
                if (item is Button)
                {
                    item.Enabled = false;
                    item.Visible = false;
                }
            }

            foreach (Control item in Controls)
            {
                if (item is TextBox)
                {
                    item.Enabled = false;
                    item.Visible = false;
                }
            }

            foreach (Control item in Controls)
            {
                if (item is Label)
                {
                    item.Visible = false;
                    item.Enabled = false;
                    item.Text = "Lisanslı Değil!";
                }
            }

            foreach (Control item in Controls)
            {
                if (item is RadioButton)
                {
                    item.Visible = false;
                    item.Enabled = false;
                }
            }

            textBox2.Enabled = true;
            textBox2.Visible = true;

            textBox3.Enabled = true;
            textBox3.Visible = true;

            button3.Enabled = true;
            button3.Visible = true;

            label1.Enabled = true;
            label1.Visible = true;

            button3.Enabled = true;
            button2.Enabled = true;
        }

        void Acik()
        {
            foreach (Control item in Controls)
            {
                if (item is Button)
                {
                    item.Enabled = true;
                    item.Enabled = true;
                }
            }

            foreach (Control item in Controls)
            {
                if (item is TextBox)
                {
                    item.Enabled = true;
                    item.Visible = true;
                }
            }

            foreach (Control item in Controls)
            {
                if (item is Label)
                {
                    item.Visible = true;
                    item.Enabled = true;
                }
            }

            foreach (Control item in Controls)
            {
                if (item is RadioButton)
                {
                    item.Visible = true;
                    item.Enabled = true;
                }
            }

            label1.Text = database.GetExternalIP();

            if (database.internetSorgu())
                label2.Text = "İnternet bağlantısı var.";
            else
                label2.Text = "İnternet bağlantısı yok.";

            if (database.baglanti_kontrol())
                label3.Text = "Mysql bağlantısı var.";
            else
                label3.Text = "Mysql bağlantısı yok.";

            label4.Text = pcId;

            int gun = database.aktifKeyGunKontrol(pcId);

            if (gun > 0)
                label5.Text = gun.ToString() + " Gün Kalmıştır.";
            else if (gun == -1)
                label5.Text = "Süresiz Seriale Sahipsiniz.";
            else if (gun == -2)
                label5.Text = "Hatalı veri!.";
            else
                label5.Text = gun.ToString() + " Gün Kalmıştır.";

            label6.Text = database.serialKeyGoster(pcId);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            database.keyUret();
            MessageBox.Show("Üretildi.");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (database.keyKontrol(textBox1.Text) || database.keyKontrol_Yedek(textBox1.Text))
                MessageBox.Show("Serial Key Var.");
            else
                MessageBox.Show("Serial Key YOK!!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (database.aktifKeyKontrol(textBox2.Text, textBox3.Text))
            {
                if (database.serialAktifEt(textBox3.Text, textBox2.Text))
                {
                    MessageBox.Show("Başarıyla Aktif Edilmiştir.\nYeniden Başlatılıyor...");
                    Application.Restart();
                    Environment.Exit(0);
                }
                else
                    MessageBox.Show("Herkes 1 serial aktif edebilir veya\nBöyle Bir Mail Bulunmamaktadır.");
            }
            else
                MessageBox.Show("Girdiğiniz Serial Hatalı veya Kullanımda.");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (database.gunKontrol())
            {
                MessageBox.Show("Başarılı.\nYeniden Başlatılıyor...");
                Application.Restart();
                Environment.Exit(0);
            }
            else
                MessageBox.Show("Hatalı!");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                string serial = database.serialKeyAl(90);
                if (database.serialSatınAl(textBox4.Text, serial))
                {
                    textBox5.Text = serial;
                    MessageBox.Show("Başarıyla Satın Alınmıştır.");
                }
                else
                    MessageBox.Show("Böyle Bir Mail Bulunmamaktadır.");
            }
            else if (radioButton2.Checked)
            {
                string serial = database.serialKeyAl(180);
                if (database.serialSatınAl(textBox4.Text, serial))
                {
                    textBox5.Text = serial;
                    MessageBox.Show("Başarıyla Satın Alınmıştır.");
                }
                else
                    MessageBox.Show("Böyle Bir Mail Bulunmamaktadır.");
            }
            else
                MessageBox.Show("Gün Seçiniz!");
            
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (database.gunAzaltKontrolveKontrolEt())
            {
                MessageBox.Show("Başarılı.\nYeniden Başlatılıyor...");
                Application.Restart();
                Environment.Exit(0);
            }
            else
                MessageBox.Show("Hatalı!");
        }
    }
}
