﻿using System;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Data;

namespace KeygenGenerator
{
    public static class database
    {
        public static MySqlConnection baglanti = new MySqlConnection("Server=localhost;Database=schoolphoto;Uid=root;Pwd='';");

        [DllImport("wininet.dll")]
        public static extern bool InternetGetConnectedState(ref InternetConnectionState lpdwFlags, int dwReserved);

        public static string GetExternalIP()
        {
            string externalIP;
            externalIP = (new System.Net.WebClient()).DownloadString("http://checkip.dyndns.org/");
            externalIP = (new System.Text.RegularExpressions.Regex(@"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}")).Matches(externalIP)[0].ToString();
            return externalIP;
        }//ip adresi gösterme kayıt yaptırmada kullanıyorum

        public static bool baglanti_kontrol()
        {
            try
            {
                baglanti.Open();
                return true;
                //Veritabanına bağlanırsa baglanti_kontrol fonksiyonu "true" değeri gönderecek
            }
            catch (Exception)
            {
                return false;
                //Veritabanına bağlanamazsa "false" değeri dönecek
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }//mysql baglantı kontrol

        public enum InternetConnectionState : int
        {
            INTERNET_CONNECTION_OFFLINE = 0x20,
            INTERNET_CONNECTION_CONFIGURED = 0x40
        }//internet kontrolü

        public static bool internetSorgu()
        {
            InternetConnectionState flags = 0;
            bool isConfigured = (flags & InternetConnectionState.INTERNET_CONNECTION_CONFIGURED) != 0;
            bool isConnected = InternetGetConnectedState(ref flags, 0);

            if (isConnected != true)
                return false;
            else
                return true;
        }//internet kontrolü

        public static bool keyKontrol(string keygen)
        {
            try
            {
                MySqlDataReader dr;
                string sorgu = "SELECT * FROM sKeygen WHERE kNo='" + keygen + "'";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                dr = kmt.ExecuteReader();
                bool sorgula = Convert.ToBoolean(dr.Read());
                if (sorgula == false)
                    return false;
                else
                    return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }//Key Kontrol Ediliyor

        public static bool keyKontrol_Yedek(string keygen)
        {
            try
            {
                MySqlDataReader dr;
                string sorgu = "SELECT * FROM sKeygen_yedek WHERE kNo='" + keygen + "'";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                dr = kmt.ExecuteReader();
                bool sorgula = Convert.ToBoolean(dr.Read());
                if (sorgula == false)
                    return false;
                else
                    return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }//Key Kontrol Ediliyor

        public static bool gunKontrol()
        {
            try
            {
                string sorgu = "Update aktifkey SET kalanGun=(SELECT kalanGun FROM satilanlar Where satKId=aktifkey.satKId)";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                kmt.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }//Gün Kontrol Ediliyor

        public static bool gunAzaltKontrolveKontrolEt()
        {
            try
            {
                //Update aktifkey SET kalanGun=(SELECT satilanlar.kalanGun FROM satilanlar Where satilanlar.satKId=aktifkey.satKId)
                string sorgu = "UPDATE satilanlar SET kalanGun=kalanGun-1";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                kmt.ExecuteNonQuery();
                baglanti.Close();

                string sorgu1 = "Update aktifkey SET kalanGun=(SELECT kalanGun FROM satilanlar Where satKId=aktifkey.satKId)";
                MySqlCommand kmt1 = new MySqlCommand(sorgu1, baglanti);
                baglanti.Open();
                kmt1.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }//Gün Sayısı Azaltılıp Kontrol Ediliyor

        public static string GetSerialNumber()
        {
            Guid serialGuid = Guid.NewGuid();
            string uniqueSerial = serialGuid.ToString("N");

            string uniqueSerialLength = uniqueSerial.Substring(0, 28).ToUpper();

            char[] serialArray = uniqueSerialLength.ToCharArray();
            string finalSerialNumber = "";

            int j = 0;
            for (int i = 0; i < 20; i++)
            {
                for (j = i; j < 4 + i; j++)
                {
                    finalSerialNumber += serialArray[j];
                }
                if (j == 20)
                {
                    break;
                }
                else
                {
                    i = (j) - 1;
                    finalSerialNumber += "-";
                }
            }

            return finalSerialNumber;
        }//Key Üretiyor

        public static bool keyUret()
        {
            try
            {
                //90 Günlük Kontrol
                int adet90, eklenen90;
                string sorgu = "SELECT COUNT(kGUN) From sKeygen WHERE kGun='90'";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                adet90 = Convert.ToInt32(kmt.ExecuteScalar());
                if (adet90 < 50)
                {
                    eklenen90 = 50 - adet90;
                    baglanti.Close();
                    for (int i = 0; i < eklenen90; i++)
                    {
                        string sorgu2 = "INSERT INTO sKeygen (kNo,kGun) values ('" + GetSerialNumber() + "','90')";
                        MySqlCommand kmt2 = new MySqlCommand(sorgu2, baglanti);
                        baglanti.Open();
                        kmt2.ExecuteNonQuery();
                        baglanti.Close();
                    }
                }

                //180 Günlük Kontrol
                int adet180, eklenen1800;
                string sorgu3 = "SELECT COUNT(kGUN) From sKeygen WHERE kGun='180'";
                MySqlCommand kmt3 = new MySqlCommand(sorgu3, baglanti);
                baglanti.Open();
                adet180 = Convert.ToInt32(kmt3.ExecuteScalar());
                if (adet180 < 50)
                {
                    eklenen1800 = 50 - adet180;
                    baglanti.Close();
                    for (int i = 0; i < eklenen1800; i++)
                    {
                        string sorgu2 = "INSERT INTO sKeygen (kNo,kGun) values ('" + GetSerialNumber() + "','180')";
                        MySqlCommand kmt2 = new MySqlCommand(sorgu2, baglanti);
                        baglanti.Open();
                        kmt2.ExecuteNonQuery();
                        baglanti.Close();
                    }
                }

                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }//Key Üretiyor

        public static int UyeId(string mail)
        {
            try
            {
                int uyeId;
                string sorgu2 = "SELECT uyeId From uyeler WHERE mail='" + mail + "'";
                MySqlCommand kmt2 = new MySqlCommand(sorgu2, baglanti);
                baglanti.Open();
                uyeId = Convert.ToInt32(kmt2.ExecuteScalar());
                return uyeId;
            }
            catch (Exception)
            {
                return 0;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }

        public static string MailtoUyeId(int uyeId)
        {
            try
            {
                string mail;
                string sorgu2 = "SELECT mail From uyeler WHERE uyeId='" + uyeId + "'";
                MySqlCommand kmt2 = new MySqlCommand(sorgu2, baglanti);
                baglanti.Open();
                mail = kmt2.ExecuteScalar().ToString();
                return mail;
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }

        public static int satKId(int uyeId)
        {
            try
            {
                int satKId;
                string sorgu3 = "SELECT satKId From satilanlar WHERE uyeId='" + uyeId + "' and kGun>'0'";
                MySqlCommand kmt3 = new MySqlCommand(sorgu3, baglanti);
                baglanti.Open();
                satKId = Convert.ToInt32(kmt3.ExecuteScalar());
                return satKId;
            }
            catch (Exception)
            {
                return 0;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }

        public static bool serialAktifEt(string mail, string serial)
        {
            try
            {
                int uyeId = UyeId(mail);
                int satilanKId = satKId(uyeId);
                string pcAdres = ComputerInfo.GetComputerId();
                int kalanGun = serialGunSatilanlar(serial);

                string sorgu = "SELECT uyeId FROM aktifkey WHERE uyeId='" + uyeId + "' and kalanGun>'0'";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                if (kmt.ExecuteScalar() == null)
                {
                    baglanti.Close();
                    string sorgu2 = "INSERT INTO aktifkey (uyeId, satKId, pcAdres, kalanGun) VALUES ('" + uyeId + "','" + satilanKId + "','" + pcAdres + "', '" + kalanGun + "')";
                    MySqlCommand kmt2 = new MySqlCommand(sorgu2, baglanti);
                    baglanti.Open();
                    kmt2.ExecuteNonQuery();
                    return true;
                }
                else
                    return false;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }//Gün Kontrol Ediliyor

        public static int serialGun(string serial)
        {
            try
            {
                int serialGun;
                string sorgu = "SELECT kGun From skeygen WHERE kNo='" + serial + "'";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                serialGun = Convert.ToInt32(kmt.ExecuteScalar());
                return serialGun;
            }
            catch (Exception)
            {
                return 0;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }

        public static int serialGunSatilanlar(string serial)
        {
            try
            {
                int serialGun;
                string sorgu = "SELECT kalanGun From satilanlar WHERE kNo='" + serial + "'";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                serialGun = Convert.ToInt32(kmt.ExecuteScalar());
                return serialGun;
            }
            catch (Exception)
            {
                return 0;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }

        public static bool serialSatınAl(string mail, string serial)
        {
            try
            {
                int keyGun = serialGun(serial);
                string sorgu = "INSERT INTO satilanlar (uyeId, kNo, kGun, kalanGun) values ('" + UyeId(mail) + "','" + serial + "','" + keyGun + "', '" + keyGun + "')";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                kmt.ExecuteNonQuery();
                baglanti.Close();

                string sorgu2 = "INSERT INTO skeygen_yedek (kNo, kGun) values ('" + serial + "','" + keyGun + "')";
                MySqlCommand kmt2 = new MySqlCommand(sorgu2, baglanti);
                baglanti.Open();
                kmt2.ExecuteNonQuery();
                baglanti.Close();

                string sorgu3 = "DELETE FROM skeygen WHERE kNo='" + serial + "'";
                MySqlCommand kmt3 = new MySqlCommand(sorgu3, baglanti);
                baglanti.Open();
                kmt3.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }//Gün Kontrol Ediliyor

        public static string serialKeyAl(int Gun)
        {
            try
            {
                string keyGun;
                string sorgu = "SELECT kNo FROM skeygen WHERE kGun='" + Gun + "' LIMIT 1";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                keyGun = kmt.ExecuteScalar().ToString();
                return keyGun;
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }//Gün Kontrol Ediliyor

        public static int aktifKeyGunKontrol(string pcAdres)
        {
            try
            {
                int kalanGun;
                object kalanDeger;
                string sorgu = "SELECT kalanGun FROM aktifkey WHERE pcAdres='" + pcAdres + "' and kalanGun>'0'";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                kalanDeger = kmt.ExecuteScalar();
                kalanGun = Convert.ToInt32(kmt.ExecuteScalar());
                if (kalanDeger != null)
                    return kalanGun;
                else
                    return 0;
            }
            catch (Exception)
            {
                return 0;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }//Key Kontrol Ediliyor

        public static bool aktifKeyKontrol(string serial, string mail)
        {
            try
            {
                int uyeId;
                object sorgu1;
                string sorgu = "SELECT uyeId FROM satilanlar WHERE kNo='" + serial + "' and kalanGun>'0'";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                sorgu1 = kmt.ExecuteScalar();
                uyeId = Convert.ToInt32(kmt.ExecuteScalar());
                baglanti.Close();
                if (MailtoUyeId(uyeId) == mail && sorgu1 != null)
                    return true;
                else
                    return false;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }//Key Kontrol Ediliyor

        public static string serialKeyGoster(string pcAdres)
        {
            try
            {
                string satKId;
                string sorgu = "SELECT satKId FROM aktifkey WHERE pcAdres='" + pcAdres + "'";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                satKId = kmt.ExecuteScalar().ToString();
                baglanti.Close();

                string serialKey;
                string sorgu1 = "SELECT kNo FROM satilanlar WHERE satKId='" + satKId + "'";
                MySqlCommand kmt1 = new MySqlCommand(sorgu1, baglanti);
                baglanti.Open();
                serialKey = kmt1.ExecuteScalar().ToString();

                return serialKey;
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }//Key Kontrol Ediliyor
    }
}
