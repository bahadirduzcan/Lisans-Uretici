-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 02 Şub 2019, 10:41:00
-- Sunucu sürümü: 5.7.17-log
-- PHP Sürümü: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `schoolphoto`
--
CREATE DATABASE IF NOT EXISTS `schoolphoto` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `schoolphoto`;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `aktifkey`
--

CREATE TABLE `aktifkey` (
  `aktifId` int(11) NOT NULL,
  `uyeId` int(11) NOT NULL,
  `satKId` int(11) NOT NULL,
  `pcAdres` varchar(39) NOT NULL,
  `aktifTarihi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `kalanGun` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `satilanlar`
--

CREATE TABLE `satilanlar` (
  `satKId` int(11) NOT NULL,
  `uyeId` int(11) NOT NULL,
  `kNo` varchar(24) NOT NULL,
  `kGun` int(11) NOT NULL,
  `satisTarihi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `kalanGun` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `skeygen`
--

CREATE TABLE `skeygen` (
  `kId` int(11) NOT NULL,
  `kNo` varchar(24) NOT NULL,
  `kGun` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `skeygen_yedek`
--

CREATE TABLE `skeygen_yedek` (
  `kId` int(11) NOT NULL,
  `kNo` varchar(24) NOT NULL,
  `kGun` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `uyeler`
--

CREATE TABLE `uyeler` (
  `uyeId` int(11) NOT NULL,
  `adSoyad` int(25) NOT NULL,
  `telefon` int(11) NOT NULL,
  `telefon2` int(11) NOT NULL,
  `Il` int(20) NOT NULL,
  `Ilce` int(20) NOT NULL,
  `adres` varchar(250) NOT NULL,
  `IsyeriAdi` varchar(30) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `sifre` varchar(32) NOT NULL,
  `kayitTarihi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `aktifkey`
--
ALTER TABLE `aktifkey`
  ADD PRIMARY KEY (`aktifId`);

--
-- Tablo için indeksler `satilanlar`
--
ALTER TABLE `satilanlar`
  ADD PRIMARY KEY (`satKId`);

--
-- Tablo için indeksler `skeygen`
--
ALTER TABLE `skeygen`
  ADD PRIMARY KEY (`kId`);

--
-- Tablo için indeksler `skeygen_yedek`
--
ALTER TABLE `skeygen_yedek`
  ADD PRIMARY KEY (`kId`);

--
-- Tablo için indeksler `uyeler`
--
ALTER TABLE `uyeler`
  ADD PRIMARY KEY (`uyeId`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `aktifkey`
--
ALTER TABLE `aktifkey`
  MODIFY `aktifId` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `satilanlar`
--
ALTER TABLE `satilanlar`
  MODIFY `satKId` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `skeygen`
--
ALTER TABLE `skeygen`
  MODIFY `kId` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `skeygen_yedek`
--
ALTER TABLE `skeygen_yedek`
  MODIFY `kId` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `uyeler`
--
ALTER TABLE `uyeler`
  MODIFY `uyeId` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
