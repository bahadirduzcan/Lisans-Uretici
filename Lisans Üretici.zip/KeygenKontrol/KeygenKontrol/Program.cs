﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Timers;
using MySql.Data.MySqlClient;

namespace KeygenKontrol
{
    class Program
    {
        public static MySqlConnection baglanti = new MySqlConnection("Server=185.50.69.30;Database=schoolphoto;Uid=root;Pwd='';");

        public static void Main(string[] args)
        {
            Console.Title = "Veritabanı Düzenleyicisi";

            Timer gunTimer = new Timer();
            gunTimer.Elapsed += new ElapsedEventHandler(gunTimedEvent);
            gunTimer.Interval = 3600000;
            gunTimer.Enabled = true;

            Timer serialTimer = new Timer();
            serialTimer.Elapsed += new ElapsedEventHandler(serialTimedEvent);
            serialTimer.Interval = 1800000;
            serialTimer.Enabled = true;

            for (; ; )
            {
                Console.ReadLine();
            }
        }

        private static void gunTimedEvent(object source, ElapsedEventArgs e)
        {
            if (gunAzaltKontrolveKontrolEt() != null)
                Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " Günler Düzenlendi.");
            else
                Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + gunAzaltKontrolveKontrolEt().ToString() + " Günler Düzenlenirken Hata ile karşılaşıldı.");
        }//Gün Sayısı Azaltılıp Kontrol Ediliyor

        private static void serialTimedEvent(object source, ElapsedEventArgs e)
        {
            if (keyUret() != null)
                Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " Serial Üretildi.");
            else
                Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + keyUret().ToString() + " Serial Hata.");
        }//Key Üretiyor

        public static object gunAzaltKontrolveKontrolEt()
        {
            try
            {
                string sorgu = "UPDATE satilanlar SET kalanGun=kGun-(datediff(CURRENT_TIMESTAMP(),satisTarihi)) Where kalanGun>'0'";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                kmt.ExecuteNonQuery();
                baglanti.Close();

                string sorgu1 = "Update aktifkey SET kalanGun=(SELECT kalanGun FROM satilanlar Where satKId=aktifkey.satKId)";
                MySqlCommand kmt1 = new MySqlCommand(sorgu1, baglanti);
                baglanti.Open();
                kmt1.ExecuteNonQuery();
                baglanti.Close();

                return "Sorgu Doğru";
            }
            catch (Exception e)
            {
                return e;
            }
        }//Gün Sayısı Azaltılıp Kontrol Ediliyor

        public static object keyUret()
        {
            try
            {
                //90 Günlük Kontrol
                int adet90, eklenen90;
                string sorgu = "SELECT COUNT(kGUN) From sKeygen WHERE kGun='90'";
                MySqlCommand kmt = new MySqlCommand(sorgu, baglanti);
                baglanti.Open();
                adet90 = Convert.ToInt32(kmt.ExecuteScalar());
                if (adet90 < 250)
                {
                    eklenen90 = 250 - adet90;
                    baglanti.Close();
                    for (int i = 0; i < eklenen90; i++)
                    {
                        string sorgu2 = "INSERT INTO sKeygen (kNo,kGun) values ('" + GetSerialNumber() + "','90')";
                        MySqlCommand kmt2 = new MySqlCommand(sorgu2, baglanti);
                        baglanti.Open();
                        kmt2.ExecuteNonQuery();
                        baglanti.Close();
                    }
                }
                else
                    baglanti.Close();

                //180 Günlük Kontrol
                int adet180, eklenen1800;
                string sorgu3 = "SELECT COUNT(kGUN) From sKeygen WHERE kGun='180'";
                MySqlCommand kmt3 = new MySqlCommand(sorgu3, baglanti);
                baglanti.Open();
                adet180 = Convert.ToInt32(kmt3.ExecuteScalar());
                if (adet180 < 250)
                {
                    eklenen1800 = 250 - adet180;
                    baglanti.Close();
                    for (int i = 0; i < eklenen1800; i++)
                    {
                        string sorgu2 = "INSERT INTO sKeygen (kNo,kGun) values ('" + GetSerialNumber() + "','180')";
                        MySqlCommand kmt2 = new MySqlCommand(sorgu2, baglanti);
                        baglanti.Open();
                        kmt2.ExecuteNonQuery();
                        baglanti.Close();
                    }
                }
                else
                    baglanti.Close();

                return "Sorgu Doğru";
            }
            catch (Exception e)
            {
                return e;
            }
        }//Key Üretiyor

        public static string GetSerialNumber()
        {
            Guid serialGuid = Guid.NewGuid();
            string uniqueSerial = serialGuid.ToString("N");

            string uniqueSerialLength = uniqueSerial.Substring(0, 28).ToUpper();

            char[] serialArray = uniqueSerialLength.ToCharArray();
            string finalSerialNumber = "";

            int j = 0;
            for (int i = 0; i < 20; i++)
            {
                for (j = i; j < 4 + i; j++)
                {
                    finalSerialNumber += serialArray[j];
                }
                if (j == 20)
                {
                    break;
                }
                else
                {
                    i = (j) - 1;
                    finalSerialNumber += "-";
                }
            }

            return finalSerialNumber;
        }//Key Üretiyor
    }
}
